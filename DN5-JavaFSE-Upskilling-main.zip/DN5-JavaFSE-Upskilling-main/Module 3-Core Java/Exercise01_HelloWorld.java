public class Exercise01_HelloWorld {

    public static void main(String[] args) {

        System.out.println("Hello, World!");

    }
}
